/**
 * 
 */
/**
 * @author Petar
 *
 */
module domashnarabota1 {
}